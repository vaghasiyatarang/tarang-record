// Primary color config object
const primaryColorConfig = [
  {
    name: 'primary-1',
    light: '#A379FF',
    main: '#8C57FF',
    dark: '#7E4EE6'
  }
]

export default primaryColorConfig
