/** @type {import('next').NextConfig} */
const nextConfig = {
  basePath: process.env.BASEPATH
}

export default nextConfig
